package com.robosoft.internmanagement.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.validation.UnexpectedTypeException;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(UnexpectedTypeException.class)
    public ResponseEntity<?> handleUnsupportedTypeException(UnexpectedTypeException unexpectedTypeException) {
        unexpectedTypeException.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to validate data");
    }

    @ExceptionHandler(DatabaseException.class)
    public ResponseEntity<?> handleDatabaseException(DatabaseException databaseException) {
        Result result = databaseException.getResult();
        Result results = new Result(result.getValue(), result.getDescription(), result.getOpinion());
        ResponseData responseData = new ResponseData("RECORD MISMATCH", results);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseData);
    }

    @ExceptionHandler(FileEmptyException.class)
    public ResponseEntity<?> handleFileEmptyException(FileEmptyException fileEmptyException) {
        Result result = fileEmptyException.getResult();
        Result results = new Result(result.getValue(), result.getDescription(), result.getOpinion());
        ResponseData responseData = new ResponseData("File not found", results);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseData);
    }

}
